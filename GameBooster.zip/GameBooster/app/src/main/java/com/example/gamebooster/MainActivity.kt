package com.example.gamebooster

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var tvRam: TextView
    private lateinit var tvBattery: TextView
    private lateinit var tvPing: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            updateStats()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    // ---------- UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float, color: String, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.parseColor(color))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }

    private fun card(vararg views: TextView): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1A1D24"))
                cornerRadius = dp(14).toFloat()
            }
            views.forEach { addView(it) }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(12) }
        }

    private fun button(text: String, color: String, onClick: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(color))
                cornerRadius = dp(14).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(54)
            ).apply { bottomMargin = dp(10) }
            setOnClickListener { onClick() }
        }

    private fun buildUi() {
        val root = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#0F1115")) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(24))
        }
        root.addView(col)

        col.addView(label("🚀 Game Booster VIP", 26f, "#FFFFFF", true).apply { gravity = Gravity.CENTER })
        col.addView(label("Miễn phí 100% – không quảng cáo", 13f, "#8A93A6").apply { gravity = Gravity.CENTER })

        tvRam = label("RAM: ...", 15f, "#E6E9F0")
        tvBattery = label("Pin: ...", 15f, "#E6E9F0")
        tvPing = label("Ping: chưa đo", 15f, "#E6E9F0")

        col.addView(card(tvRam, tvBattery).apply { (layoutParams as LinearLayout.LayoutParams).topMargin = dp(20) })
        col.addView(card(tvPing))

        col.addView(button("⚡ Tăng tốc & mở game", "#E8452C") { pickGame() })
        col.addView(button("🧹 Dọn RAM", "#2D7FF9") { cleanRam { freed ->
            toast("Đã giải phóng khoảng $freed MB RAM")
            updateStats()
        } })
        col.addView(button("📶 Đo ping", "#12A36B") { measurePing() })
        col.addView(button("🔕 Bật Không làm phiền", "#7A5AF8") {
            if (!enableDnd()) toast("Hãy cấp quyền cho app ở màn hình vừa mở, rồi bấm lại")
            else toast("Đã bật Không làm phiền")
        })
        col.addView(button("🔔 Tắt Không làm phiền", "#4B5563") { disableDnd() })

        col.addView(
            label(
                "Lưu ý: app chỉ dọn tiến trình nền và giảm gián đoạn. " +
                    "Không có app nào làm máy yếu chơi mượt như máy mạnh.",
                12f, "#6B7385"
            ).apply { setPadding(0, dp(12), 0, 0) }
        )

        setContentView(root)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------- Thống kê ----------

    private fun availMb(): Long {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.availMem / 1048576
    }

    private fun updateStats() {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val totalMb = mi.totalMem / 1048576
        val freeMb = mi.availMem / 1048576
        val usedPct = if (totalMb > 0) 100 - freeMb * 100 / totalMb else 0
        tvRam.text = "RAM: trống $freeMb MB / $totalMb MB (đang dùng $usedPct%)"

        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val pct = if (scale > 0) level * 100 / scale else -1
        tvBattery.text = "Pin: $pct%  •  Nhiệt độ: $temp°C"
    }

    // ---------- Dọn RAM ----------

    private fun cleanRam(onDone: (Long) -> Unit) {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val before = availMb()
        packageManager.getInstalledApplications(0).forEach { ai ->
            val isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (!isSystem && ai.packageName != packageName) {
                am.killBackgroundProcesses(ai.packageName)
            }
        }
        handler.postDelayed({
            val after = availMb()
            onDone(maxOf(0L, after - before))
        }, 1000)
    }

    // ---------- Ping ----------

    private fun measurePing() {
        tvPing.text = "Ping: đang đo..."
        thread {
            val results = mutableListOf<Long>()
            repeat(5) {
                try {
                    val start = System.nanoTime()
                    Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 2000) }
                    results.add((System.nanoTime() - start) / 1_000_000)
                } catch (_: Exception) {
                }
            }
            runOnUiThread {
                tvPing.text = if (results.isEmpty()) {
                    "Ping: không kết nối được mạng"
                } else {
                    val avg = results.average().toInt()
                    val quality = when {
                        avg < 50 -> "Rất tốt"
                        avg < 100 -> "Ổn"
                        avg < 200 -> "Hơi lag"
                        else -> "Lag nặng"
                    }
                    "Ping: $avg ms (thấp nhất ${results.min()}, cao nhất ${results.max()}) – $quality"
                }
            }
        }
    }

    // ---------- Không làm phiền ----------

    private fun enableDnd(): Boolean {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        return if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            true
        } else {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            false
        }
    }

    private fun disableDnd() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
            toast("Đã tắt Không làm phiền")
        } else {
            toast("Chưa cấp quyền Không làm phiền")
        }
    }

    // ---------- Chọn game & tăng tốc ----------

    private fun pickGame() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }

        if (apps.isEmpty()) {
            toast("Không tìm thấy ứng dụng nào")
            return
        }

        AlertDialog.Builder(this)
            .setTitle("Chọn game để tăng tốc")
            .setItems(apps.map { it.first }.toTypedArray()) { _, i -> boostAndLaunch(apps[i].second) }
            .show()
    }

    private fun boostAndLaunch(pkg: String) {
        toast("Đang tăng tốc...")
        cleanRam { freed ->
            val dnd = enableDnd()
            toast("Giải phóng ~$freed MB" + if (dnd) " • Đã bật Không làm phiền" else "")
            packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
        }
    }
}
