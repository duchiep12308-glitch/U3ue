# Game Booster VIP (Android, Kotlin)

Tính năng: dọn RAM, đo ping, xem RAM/pin/nhiệt độ, bật/tắt Không làm phiền, chọn game rồi tăng tốc + mở game.

## Cách 1: Lấy APK miễn phí bằng GitHub (không cần cài gì)

1. Tạo tài khoản GitHub, tạo repository mới (Public hoặc Private).
2. Upload toàn bộ nội dung thư mục này lên repo (giữ nguyên thư mục `.github`).
3. Vào tab **Actions** → chọn **Build APK** → **Run workflow** (hoặc chờ nó tự chạy sau khi upload).
4. Khi chạy xong (khoảng 3–5 phút), mở lần chạy đó → mục **Artifacts** → tải **GameBooster-APK**.
5. Giải nén ra `app-debug.apk`, copy vào điện thoại, mở file để cài (bật "Cài đặt từ nguồn không rõ" nếu máy hỏi).

## Cách 2: Build bằng Android Studio

1. Mở thư mục này bằng Android Studio, chờ Gradle sync.
2. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. File nằm ở `app/build/outputs/apk/debug/app-debug.apk`.

## Lưu ý

- Lần đầu bấm "Bật Không làm phiền", Android sẽ mở màn hình cấp quyền; bật cho Game Booster VIP rồi quay lại.
- App chỉ dọn được tiến trình nền của các app bạn cài; không thể làm máy yếu mạnh lên.
